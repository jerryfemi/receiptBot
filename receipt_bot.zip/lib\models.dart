import 'package:json_annotation/json_annotation.dart';

part 'models.g.dart';

enum OnboardingStatus {
  new_user,
  awaiting_address,
  awaiting_phone,
  awaiting_logo,
  active,
}

enum UserAction {
  idle,
  createReceipt,
  editName,
  editPhone,
  editLogo,
  createInvoice,
  editBankDetails,
  selectTheme,
  editProfileMenu,
}

enum TransactionType {
  receipt,
  invoice,
}

@JsonSerializable()
class BusinessProfile {
  final String phoneNumber;
  final OnboardingStatus status;
  final UserAction currentAction; // New Field
  final String? businessName;
  final String? businessAddress;
  final String? displayPhoneNumber;
  final String? logoUrl;
  final String? bankName;
  final String? accountNumber;
  final String? accountName;
  final Transaction?
      pendingTransaction; // Temporary storage for theme selection
  final int themeIndex;

  BusinessProfile({
    required this.phoneNumber,
    this.status = OnboardingStatus.new_user,
    this.currentAction = UserAction.idle,
    this.businessName,
    this.businessAddress,
    this.displayPhoneNumber,
    this.logoUrl,
    this.bankName,
    this.accountNumber,
    this.accountName,
    this.pendingTransaction,
    this.themeIndex = 0, // Default to 0 (Classic)
  });

  factory BusinessProfile.fromJson(Map<String, dynamic> json) =>
      _$BusinessProfileFromJson(json);

  Map<String, dynamic> toJson() => _$BusinessProfileToJson(this);

  BusinessProfile copyWith({
    String? phoneNumber,
    OnboardingStatus? status,
    UserAction? currentAction,
    String? businessName,
    String? businessAddress,
    String? displayPhoneNumber,
    String? logoUrl,
    String? bankName,
    String? accountNumber,
    String? accountName,
    Transaction? pendingTransaction,
    int? themeIndex,
  }) {
    return BusinessProfile(
      phoneNumber: phoneNumber ?? this.phoneNumber,
      status: status ?? this.status,
      currentAction: currentAction ?? this.currentAction,
      businessName: businessName ?? this.businessName,
      businessAddress: businessAddress ?? this.businessAddress,
      displayPhoneNumber: displayPhoneNumber ?? this.displayPhoneNumber,
      logoUrl: logoUrl ?? this.logoUrl,
      bankName: bankName ?? this.bankName,
      accountNumber: accountNumber ?? this.accountNumber,
      accountName: accountName ?? this.accountName,
      pendingTransaction: pendingTransaction ?? this.pendingTransaction,
      themeIndex: themeIndex ?? this.themeIndex,
    );
  }
}

@JsonSerializable()
class ReceiptItem {
  final String description;
  final double amount;
  final int quantity;

  ReceiptItem({
    required this.description,
    required this.amount,
    this.quantity = 1,
  });

  factory ReceiptItem.fromJson(Map<String, dynamic> json) =>
      _$ReceiptItemFromJson(json);

  Map<String, dynamic> toJson() => _$ReceiptItemToJson(this);
}

@JsonSerializable()
class Transaction {
  final String customerName;
  final String? customerAddress;
  final String? customerPhone;
  final List<ReceiptItem> items;
  final double totalAmount;
  final String? amountInWords;
  final DateTime date;
  final TransactionType type;
  final DateTime? dueDate;
  final String? bankName;
  final String? accountNumber;
  final String? accountName;

  Transaction({
    required this.customerName,
    this.customerAddress,
    this.customerPhone,
    required this.items,
    required this.totalAmount,
    this.amountInWords,
    required this.date,
    this.type = TransactionType.receipt,
    this.dueDate,
    this.bankName,
    this.accountNumber,
    this.accountName,
  });

  factory Transaction.fromJson(Map<String, dynamic> json) =>
      _$TransactionFromJson(json);

  Map<String, dynamic> toJson() => _$TransactionToJson(this);
}
