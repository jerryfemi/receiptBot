import 'package:google_generative_ai/google_generative_ai.dart';

void main() async {
  const apiKey = 'AIzaSyDcuu0IKF1plTMAHaOs4y7ipG__EfeWQkc';

  // Try to find a working model
  final models = [
    'gemini-1.5-flash',
    'gemini-1.5-flash-001',
    'gemini-1.0-pro',
    'gemini-1.0-pro-001',
    'gemini-pro',
  ];

  for (final m in models) {
    print('Testing model: $m ...');
    try {
      final model = GenerativeModel(model: m, apiKey: apiKey);
      final content = [Content.text('Hello')];
      final response = await model.generateContent(content);
      print('SUCCESS: $m works!');
      if (response.text != null) {
        print('Response: ${response.text!}');
      }
      return;
    } catch (e) {
      print('FAILED: $m. Error: $e');
    }
    print('---');
  }
}
