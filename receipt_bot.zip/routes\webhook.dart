// ignore: duplicate_ignore
// ignore: lines_longer_than_80_chars
// ignore_for_file: lines_longer_than_80_chars

import 'dart:convert';

import 'dart:io';

import 'package:dart_frog/dart_frog.dart';
import 'package:http/http.dart' as http;
import 'package:receipt_bot/firestore_service.dart';
import 'package:receipt_bot/gemini_service.dart';
import 'package:receipt_bot/models.dart';
import 'package:receipt_bot/pdf_service.dart';

// Configuration
const String _verifyToken = 'my_secure_receipt_token';
const String _whatsappToken =
    'EAANlxDnucr8BQp4fDoZB2D8xh09PcG6fYeUIQz5mOmyNfDicJ4mhdF2Tzk9a888CK4M9HyTqm5X7IRcLK21eNqTai8MVi1wDt24nwRS8dd9ZAEhyoMpUoWSvocoIzqJ49QbJEaJ4hsqTQZCoZB0ZCZBZArfyfog7JZCOilIeVsWUJfZChfZAgvoN7ImtjkpGMs2xuUvzM3MKZBwZCPmnOIdlTQtNP8MVUU6Yw7wydBhgkMhslIvEArIcQYUODnzXE4B05iij6sZCG5f6nUTPL6jUo0QbcKsGkPQZDZD';
const String _phoneNumberId = '1039228425930450';
const String _projectId = 'invoicemaker-b3876';
const String _geminiApiKey = 'AIzaSyDcuu0IKF1plTMAHaOs4y7ipG__EfeWQkc';

// const String _host = 'https://unethnological-corrin-ceratoid.ngrok-free.dev';

// Service Instances (Lazy initialization or via Middleware)
final _firestoreService = FirestoreService(projectId: _projectId);
late final GeminiService _geminiService;
final _pdfService = PdfService();
bool _servicesInitialized = false;

Future<Response> onRequest(RequestContext context) async {
  print('HIT!');
  final request = context.request;

  // 1. WhatsApp Verification (GET)
  if (request.method == HttpMethod.get) {
    final params = request.uri.queryParameters;
    if (params['hub.mode'] == 'subscribe' &&
        params['hub.verify_token'] == _verifyToken) {
      print('Webhook verified!');
      return Response(body: params['hub.challenge']);
    }
    return Response(statusCode: 403, body: 'Verification failed');
  }

  // Initialize services only for other requests (POST)
  if (!_servicesInitialized) {
    // Wrap in try-catch to prevent crashing if config is missing
    try {
      final serviceAccountContent =
          await File('service_account.json').readAsString();
      await _firestoreService.initialize(serviceAccountContent);
      _geminiService = GeminiService(apiKey: _geminiApiKey);
      _servicesInitialized = true;
    } catch (e) {
      print('Service initialization failed: $e');
      // We continue, but subsequent calls to services might fail
    }
  }

  // 2. Handle Messages (POST)
  if (request.method == HttpMethod.post) {
    print('Received POST request');
    final body = await request.body();
    // print('Raw Body: $body'); // Clean logs
    final json = jsonDecode(body);

    try {
      final entry = json['entry'][0];
      final changes = entry['changes'][0]['value'];

      if (changes['messages'] != null) {
        final message = changes['messages'][0];
        final from = message['from'] as String;
        final type = message['type'] as String;
        String text = '';

        if (type == 'text') {
          text = message['text']['body'] as String;
        } else if (type == 'image') {
          text = (message['caption'] ?? '') as String;
        }

        await _handleMessage(from, text, type, message as Map<String, dynamic>);
      }
    } catch (e) {
      print('Error parsing webhook payload: $e');
    }

    return Response(body: 'EVENT_RECEIVED');
  }

  return Response(statusCode: 404);
}

Future<void> _handleMessage(String from, String text, String type,
    Map<String, dynamic> messageData) async {
  print('--- Handling message from $from ---');
  print('Text: $text');

  try {
    // 1. Get Profile
    var profile = await _firestoreService.getProfile(from);

    // If no profile, create new one
    if (profile == null) {
      print('Creating new user profile...');
      profile = BusinessProfile(phoneNumber: from);
      await _firestoreService.updateOnboardingStep(
          from, OnboardingStatus.new_user);

      await _sendWhatsAppMessage(from,
          "Welcome to Receipt Bot 🚀! Let's set up your business profile.\n\nWhat is your **Business Name**?");
      return;
    }

    // 2. State Machine
    switch (profile.status) {
      case OnboardingStatus.new_user:
        await _firestoreService.updateOnboardingStep(
          from,
          OnboardingStatus.awaiting_address,
          data: {'businessName': text},
        );
        await _sendWhatsAppMessage(
            from, 'Great! Now, what is your **Business Address**?');
        break;

      case OnboardingStatus.awaiting_address:
        await _firestoreService.updateOnboardingStep(
          from,
          OnboardingStatus.awaiting_phone,
          data: {'businessAddress': text},
        );
        await _sendWhatsAppMessage(
            from, 'Got it. What **Phone Number** should show on the receipt?');
        break;

      case OnboardingStatus.awaiting_phone:
        await _firestoreService.updateOnboardingStep(
          from,
          OnboardingStatus.awaiting_logo,
          data: {'displayPhoneNumber': text},
        );
        await _sendWhatsAppMessage(from,
            'Almost done! Please **upload your Business Logo** (send an image).');
        break;

      case OnboardingStatus.awaiting_logo:
        if (type == 'image') {
          // Handle Image Upload
          final imageId = messageData['image']['id'];
          // 1. Get WhatsApp URL
          final tempUrl = await _getWhatsAppMediaUrl(imageId as String);

          // 2. Download Bytes
          final bytes = await _downloadFileBytes(tempUrl);

          // 3. Upload to Cloud Storage
          final publicUrl = await _firestoreService.uploadFile(
              'logos/$from.jpg', bytes, 'image/jpeg');

          await _firestoreService.saveLogoUrl(from, publicUrl);

          await _sendWhatsAppMessage(from,
              "Setup Complete! 🎉\n\nYou can now create receipts!\n\nSend 'Create Receipt' to start, or just type the details.");
        } else {
          await _sendWhatsAppMessage(
            from,
            'Please send an **image** for your logo to complete setup.',
          );
        }
        break;

      case OnboardingStatus.active:
        await _handleActiveUser(from, text, type, messageData, profile);
        break;
    }
  } catch (e) {
    print('Error in _handleMessage: $e');
    // If we fail outside the state machine (e.g. Firestore error)
    await _sendWhatsAppMessage(from, "System Error: $e");
  }
}

Future<void> _handleActiveUser(
  String from,
  String text,
  String type,
  Map<String, dynamic> messageData,
  BusinessProfile profile,
) async {
  // 1. Check for Global Commands (Only if text)
  if (type == 'text') {
    final lower = text.toLowerCase().trim();
    if (lower == 'menu' ||
        lower == 'hey' ||
        lower == 'hello' ||
        lower == 'hi') {
      await _firestoreService.updateAction(from, UserAction.idle);
      await _sendWhatsAppMessage(from,
          "Hey! What can I do for you?\n\n🔹 *Create Receipt*\n🔹 *Create Invoice*\n🔹 *Edit Profile* (Name, Bank, Theme)\n🔹 *Upload New Logo*");
      return;
    }
    if (lower == 'create receipt') {
      await _firestoreService.updateAction(from, UserAction.createReceipt);
      await _sendWhatsAppMessage(from,
          "Please provide the receipt details:\n\n- Customer Name\n- Items Bought & Prices\n- Address (optional)\n- Phone (optional)");
      return;
    }
    if (lower == 'create invoice') {
      await _firestoreService.updateAction(from, UserAction.createInvoice);
      // Check if bank details exist
      final hasBankDetails =
          profile.bankName != null && profile.accountNumber != null;
      if (hasBankDetails) {
        await _sendWhatsAppMessage(from,
            "Please provide the INVOICE details:\n\n- Client Name\n- Items & Prices\n- Due Date (optional)\n- Address/Phone");
      } else {
        await _sendWhatsAppMessage(from,
            "Please provide the INVOICE details:\n\n- Client Name\n- Items & Prices\n- Due Date\n\n⚠️ **Also, please include your Bank Details (Bank Name, Account Number, Name) to save for future invoices.**");
      }
      return;
    }
    if (lower == 'edit profile') {
      await _firestoreService.updateAction(from, UserAction.editProfileMenu);
      await _sendWhatsAppMessage(from,
          "What would you like to update?\n\n1️⃣ Business Name\n2️⃣ Phone Number\n3️⃣ Bank Details\n4️⃣ Theme / Style\n\nReply with the number.");
      return;
    }
    if (lower == 'upload new logo') {
      await _firestoreService.updateAction(from, UserAction.editLogo);
      await _sendWhatsAppMessage(from, "Okay, send me the **New Logo Image**.");
      return;
    }
    if (lower == 'cancel') {
      await _firestoreService.updateAction(from, UserAction.idle);
      await _sendWhatsAppMessage(from, "Action cancelled.");
      return;
    }
  }

  // 2. Handle Current Action
  switch (profile.currentAction) {
    case UserAction.createReceipt:
      await _processReceiptResult(from, text, profile, isInvoice: false);
      break;
    case UserAction.createInvoice:
      await _processReceiptResult(from, text, profile, isInvoice: true);
      break;
    case UserAction.editProfileMenu:
      if (text.contains('1')) {
        await _firestoreService.updateAction(from, UserAction.editName);
        await _sendWhatsAppMessage(
            from, "Okay, send me the **New Business Name**.");
      } else if (text.contains('2')) {
        await _firestoreService.updateAction(from, UserAction.editPhone);
        await _sendWhatsAppMessage(
            from, "Okay, send me the **New Phone Number**.");
      } else if (text.contains('3')) {
        await _firestoreService.updateAction(from, UserAction.editBankDetails);
        await _sendWhatsAppMessage(from,
            "Okay, send me your **Bank Details**:\n\nBank Name, Account Number, Account Name");
      } else if (text.contains('4')) {
        await _firestoreService.updateAction(from, UserAction.selectTheme);
        await _sendWhatsAppMessage(from,
            "Select a default style for your documents:\n\n1️⃣ Classic (B&W)\n2️⃣ Beige Corporate\n3️⃣ Blue Accent\n\nReply with 1, 2, or 3.");
      } else {
        await _sendWhatsAppMessage(from, "Please reply with 1, 2, 3, or 4.");
      }
      break;

    case UserAction.editBankDetails:
      // Use Gemini to parse bank details
      try {
        final transaction = await _geminiService.parseTransaction(text);
        if (transaction.bankName != null) {
          await _firestoreService
              .updateOnboardingStep(from, OnboardingStatus.active, data: {
            'bankName': transaction.bankName,
            'accountNumber': transaction.accountNumber,
            'accountName': transaction.accountName,
          });
          await _sendWhatsAppMessage(from, "Bank Details Updated! ✅");
        } else {
          await _sendWhatsAppMessage(from,
              "I couldn't find bank details. Please try again (e.g. GTBank, 0123456789, Name).");
        }
        await _firestoreService.updateAction(from, UserAction.idle);
      } catch (e) {
        await _sendWhatsAppMessage(
            from, "Error parsing details. Please try again.");
      }
      break;

    case UserAction.selectTheme:
      await _handleThemeSelection(from, text, profile);
      break;

    case UserAction.editName:
      if (type == 'text') {
        await _firestoreService.updateOnboardingStep(
            from, OnboardingStatus.active,
            data: {'businessName': text});
        await _firestoreService.updateAction(from, UserAction.idle);
        await _sendWhatsAppMessage(from, "Business Name updated to '$text'! ✅");
      } else {
        await _sendWhatsAppMessage(from, "Please send text for the name.");
      }
      break;

    case UserAction.editPhone:
      if (type == 'text') {
        await _firestoreService.updateOnboardingStep(
            from, OnboardingStatus.active,
            data: {'displayPhoneNumber': text});
        await _firestoreService.updateAction(from, UserAction.idle);
        await _sendWhatsAppMessage(from, "Phone Number updated to '$text'! ✅");
      } else {
        await _sendWhatsAppMessage(
            from, "Please send text for the phone number.");
      }
      break;

    case UserAction.editLogo:
      if (type == 'image') {
        final imageId = messageData['image']['id'];
        final tempUrl = await _getWhatsAppMediaUrl(imageId as String);

        final bytes = await _downloadFileBytes(tempUrl);
        final publicUrl = await _firestoreService.uploadFile(
            'logos/$from.jpg', bytes, 'image/jpeg');

        await _firestoreService.saveLogoUrl(from, publicUrl);
        await _firestoreService.updateAction(from, UserAction.idle);
        await _sendWhatsAppMessage(from, "Logo updated successfully! 🖼️");
      } else {
        await _sendWhatsAppMessage(from, "Please send an image.");
      }
      break;

    case UserAction.idle:
      // Legacy Flow / Fallback
      if (type == 'text') {
        // Simple heuristic: Does it look like a receipt?
        // Or just try to parse regardless?
        // User asked for "create receipt" flow.
        // But for convenience, we can try to parse if it's long enough or contains keywords?
        // Let's just try to parse. If Gemini fails, it prompts error.
        await _processReceiptResult(from, text, profile, isInvoice: false);
      } else {
        // await _sendWhatsAppMessage(from, "Please send text to generate a receipt.");
        // Silent fallback or helpful hint?
        // Maybe check if it's very short?
        if (text.length < 5) {
          await _sendWhatsAppMessage(
              from, "Please send text to generate a receipt or type 'Menu'.");
        } else {
          await _processReceiptResult(from, text, profile, isInvoice: false);
        }
      }
      break;
    default:
      await _sendWhatsAppMessage(
          from, "I'm not sure what to do. Type 'menu' to see options.");
      await _firestoreService.updateAction(from, UserAction.idle);
  }
}

Future<void> _processReceiptResult(
    String from, String text, BusinessProfile profile,
    {required bool isInvoice}) async {
  await _sendWhatsAppMessage(from, 'Generating receipt... ⏳');
  try {
    // AI Parsing
    final transaction = await _geminiService.parseTransaction(text);

    // 4. Update Profile with new bank details if found
    if (transaction.bankName != null || transaction.accountNumber != null) {
      final updates = <String, dynamic>{};
      if (transaction.bankName != null)
        updates['bankName'] = transaction.bankName;
      if (transaction.accountNumber != null)
        updates['accountNumber'] = transaction.accountNumber;
      if (transaction.accountName != null)
        updates['accountName'] = transaction.accountName;

      if (updates.isNotEmpty) {
        await _firestoreService.updateProfileData(from, updates);
        // Update local profile for PDF generation
        profile = profile.copyWith(
            bankName: transaction.bankName ?? profile.bankName,
            accountNumber: transaction.accountNumber ?? profile.accountNumber,
            accountName: transaction.accountName ?? profile.accountName);
      }
    }

    // 5. Save Pending Transaction & Ask for Theme
    await _firestoreService.updateProfileData(from, {
      'pendingTransaction': jsonEncode(transaction.toJson()),
      'currentAction': UserAction.selectTheme.name
    });

    await _sendWhatsAppMessage(
        from,
        "Got it! 🧾\n\nSelect a style for your ${isInvoice ? 'Invoice' : 'Receipt'}:\n\n"
        "1️⃣ *Classic (B&W)*\n"
        "2️⃣ *Beige Corporate*\n"
        "3️⃣ *Blue Accent*\n\n"
        "Reply with 1, 2, or 3.");
  } catch (e) {
    print('Error generating receipt: $e');
    await _sendWhatsAppMessage(
      from,
      "⚠️ Error: I couldn't process that.\n\nDetails: $e\n\nPlease try again or type 'Create Receipt' for help.",
    );
  }
}

Future<void> _handleThemeSelection(
    String from, String body, BusinessProfile profile) async {
  if (profile.pendingTransaction == null) {
    await _sendWhatsAppMessage(from, "Session expired. Please start over.");
    await _firestoreService.updateAction(from, UserAction.idle);
    return;
  }

  int themeIndex = 0;
  if (body.contains("1") || body.toLowerCase().contains("classic"))
    themeIndex = 0;
  else if (body.contains("2") || body.toLowerCase().contains("beige"))
    themeIndex = 1;
  else if (body.contains("3") || body.toLowerCase().contains("blue"))
    themeIndex = 2;

  await _sendWhatsAppMessage(from, "Generating PDF... ⏳");

  try {
    final pdfBytes = await _pdfService.generateReceipt(
        profile, profile.pendingTransaction!,
        themeIndex: themeIndex);

    // Upload and Send
    final fileName =
        '${profile.pendingTransaction!.type == TransactionType.invoice ? "invoice" : "receipt"}_${DateTime.now().millisecondsSinceEpoch}.pdf';
    final pdfUrl = await _firestoreService.uploadFile(
        'receipts/$from/$fileName', pdfBytes, 'application/pdf');

    await _sendWhatsAppMessage(from,
        "Here is your ${profile.pendingTransaction!.type == TransactionType.invoice ? "Invoice" : "Receipt"}! 👇");
    await _sendWhatsAppMedia(from, pdfUrl, fileName);

    await _firestoreService
        .updateProfileData(from, {'pendingTransaction': ''}); // Clear pending
    await _firestoreService.updateAction(from, UserAction.idle);
  } catch (e) {
    print("Error generating PDF in theme selection: $e");
    await _sendWhatsAppMessage(
        from, "Failed to generate PDF. Please try again.");
    await _firestoreService.updateAction(from, UserAction.idle);
  }
}

Future<void> _sendWhatsAppMessage(String to, String message) async {
  final url =
      Uri.parse('https://graph.facebook.com/v17.0/$_phoneNumberId/messages');
  final headers = {
    'Authorization': 'Bearer $_whatsappToken',
    'Content-Type': 'application/json',
  };
  final body = jsonEncode({
    'messaging_product': 'whatsapp',
    'to': to,
    'type': 'text',
    'text': {'body': message},
  });

  try {
    final response = await http.post(url, headers: headers, body: body);
    if (response.statusCode != 200) {
      print('Failed to send WhatsApp message: ${response.body}');
    }
  } catch (e) {
    print('Error sending WhatsApp message: $e');
  }
}

Future<String> _getWhatsAppMediaUrl(String mediaId) async {
  // 1. Get URL from Media ID
  final url = Uri.parse('https://graph.facebook.com/v17.0/$mediaId');
  final headers = {
    'Authorization': 'Bearer $_whatsappToken',
  };
  final response = await http.get(url, headers: headers);
  if (response.statusCode == 200) {
    final json = jsonDecode(response.body);
    return json['url'] as String; // This is the download URL
  } else {
    throw Exception('Failed to get media URL: ${response.body}');
  }
}

Future<List<int>> _downloadFileBytes(String url) async {
  final headers = {
    'Authorization': 'Bearer $_whatsappToken', // Required for WhatsApp media
  };

  final response = await http.get(Uri.parse(url), headers: headers);
  if (response.statusCode == 200) {
    return response.bodyBytes;
  } else {
    throw Exception('Failed to download file: ${response.statusCode}');
  }
}

Future<void> _sendWhatsAppMedia(
    String to, String mediaUrl, String filename) async {
  final url =
      Uri.parse('https://graph.facebook.com/v17.0/$_phoneNumberId/messages');
  final headers = {
    'Authorization': 'Bearer $_whatsappToken',
    'Content-Type': 'application/json',
  };

  final body = jsonEncode({
    'messaging_product': 'whatsapp',
    'to': to,
    'type': 'document',
    'document': {
      'link': mediaUrl,
      'filename': filename,
      // 'caption': 'Here is your document'
    }
  });

  try {
    final response = await http.post(url, headers: headers, body: body);
    if (response.statusCode != 200) {
      print('Failed to send WhatsApp media: ${response.body}');
    }
  } catch (e) {
    print('Error sending WhatsApp media: $e');
  }
}
