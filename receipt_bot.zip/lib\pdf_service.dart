// import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:receipt_bot/models.dart';

class PdfService {
  Future<Uint8List> generateReceipt(
    BusinessProfile profile,
    Transaction transaction, {
    int themeIndex = 0, // 0: B&W, 1: Beige, 2: Blue
  }) async {
    final pdf = pw.Document();

    // 1. Load Logo
    pw.MemoryImage? logoImage;
    if (profile.logoUrl != null) {
      try {
        final response = await http.get(Uri.parse(profile.logoUrl!));
        if (response.statusCode == 200) {
          logoImage = pw.MemoryImage(response.bodyBytes);
        }
      } catch (e) {
        print('Error loading logo: $e');
      }
    }

    // Define Theme Colors
    PdfColor bg;
    PdfColor primary;
    PdfColor textColor = PdfColors.black;

    switch (themeIndex) {
      case 1: // Beige
        bg = PdfColor.fromHex('#EFE9DB');
        primary = PdfColor.fromHex('#D73138');
        break;
      case 2: // Blue
        bg = PdfColor.fromHex('#E3F2FD'); // Light Blue
        primary = PdfColor.fromHex('#1565C0'); // Dark Blue
        break;
      case 0: // B&W (Default)
      default:
        bg = PdfColors.white;
        primary = PdfColors.black;
        break;
    }

    // Use MultiPage to support PageTheme properly
    pdf.addPage(pw.MultiPage(
      pageTheme: pw.PageTheme(
        pageFormat: PdfPageFormat.a5,
        margin: const pw.EdgeInsets.all(20), // Smaller margin for A5
        buildBackground: (context) => pw.FullPage(
          ignoreMargins: true,
          child: pw.Container(color: bg),
        ),
      ),
      build: (context) => [
        if (transaction.type == TransactionType.invoice)
          _generateInvoiceLayout(
              context, profile, transaction, logoImage, primary, textColor)
        else
          _generateReceiptLayout(
              context, profile, transaction, logoImage, primary, textColor)
      ],
    ));

    return pdf.save();
  }

  // --- CORPORATE INVOICE LAYOUT ---
  pw.Widget _generateInvoiceLayout(
      pw.Context context,
      BusinessProfile profile,
      Transaction transaction,
      pw.MemoryImage? logoImage,
      PdfColor primary,
      PdfColor textColor) {
    final headerFont = pw.Font.helveticaBold();
    final bodyFont = pw.Font.courier();

    final titleStyle = pw.TextStyle(
        font: headerFont,
        fontSize: 32,
        color: primary,
        letterSpacing: 2); // Smaller font for A5
    final companyNameStyle =
        pw.TextStyle(font: headerFont, fontSize: 18, color: primary);
    final labelBold = pw.TextStyle(
        font: bodyFont,
        fontWeight: pw.FontWeight.bold,
        fontSize: 9,
        color: textColor);
    final bodyText =
        pw.TextStyle(font: bodyFont, fontSize: 9, color: textColor);
    final microText = pw.TextStyle(
        font: bodyFont, fontSize: 7, color: PdfColor.fromHex('#4A4A4A'));

    return pw
        .Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      // 1. Header Row
      pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Text("INVOICE", style: titleStyle),
        pw.Expanded(
            child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            pw.Text(profile.businessName?.toUpperCase() ?? "BUSINESS NAME",
                style: companyNameStyle, textAlign: pw.TextAlign.right),
            pw.Text(profile.businessAddress ?? "Address Line 1",
                style: bodyText, textAlign: pw.TextAlign.right),
            pw.Text(profile.displayPhoneNumber ?? profile.phoneNumber,
                style: bodyText, textAlign: pw.TextAlign.right),
          ],
        ))
      ]),
      pw.SizedBox(height: 20),

      // 2. Invoice Meta Row
      pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text(
            "INVOICE NUMBER: #${transaction.date.millisecondsSinceEpoch.toString().substring(6)}",
            style: bodyText),
        pw.Text("DATE: ${transaction.date.toString().split(' ')[0]}",
            style: bodyText),
        if (transaction.dueDate != null)
          pw.Text("DUE DATE: ${transaction.dueDate.toString().split(' ')[0]}",
              style: bodyText),
      ]),
      pw.SizedBox(height: 20),

      // 3. Billing Row
      pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            // Bill To
            pw.Expanded(
                child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                  pw.Text("Bill To:", style: labelBold),
                  pw.Text(transaction.customerName, style: bodyText),
                  if (transaction.customerAddress != null)
                    pw.Text(transaction.customerAddress!, style: bodyText),
                  if (transaction.customerPhone != null)
                    pw.Text(transaction.customerPhone!, style: bodyText),
                ])),
            // Payment Method (Bank Details)
            if (profile.bankName != null || transaction.bankName != null)
              pw.Expanded(
                  child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                    pw.Text("Payment Method", style: labelBold),
                    pw.Text(profile.bankName ?? transaction.bankName ?? '',
                        style: bodyText, textAlign: pw.TextAlign.right),
                    pw.Text(
                        profile.accountName ?? transaction.accountName ?? '',
                        style: bodyText,
                        textAlign: pw.TextAlign.right),
                    pw.Text(
                        profile.accountNumber ??
                            transaction.accountNumber ??
                            '',
                        style: bodyText,
                        textAlign: pw.TextAlign.right),
                  ]))
          ]),
      pw.SizedBox(height: 20),

      // 4. Items Table
      pw.Table(
          border: pw.TableBorder(
            top: pw.BorderSide(color: textColor),
            bottom: pw.BorderSide(color: textColor),
            horizontalInside: pw.BorderSide(color: textColor),
          ),
          columnWidths: {
            0: const pw.FlexColumnWidth(3), // Description
            1: const pw.FlexColumnWidth(1), // Qty
            2: const pw.FlexColumnWidth(1.5), // Price
            3: const pw.FlexColumnWidth(1.5), // Subtotal
          },
          children: [
            pw.TableRow(children: [
              pw.Padding(
                  padding: const pw.EdgeInsets.all(5),
                  child: pw.Text("DESCRIPTION", style: labelBold)),
              pw.Padding(
                  padding: const pw.EdgeInsets.all(5),
                  child: pw.Text("QTY",
                      style: labelBold, textAlign: pw.TextAlign.center)),
              pw.Padding(
                  padding: const pw.EdgeInsets.all(5),
                  child: pw.Text("PRICE",
                      style: labelBold, textAlign: pw.TextAlign.center)),
              pw.Padding(
                  padding: const pw.EdgeInsets.all(5),
                  child: pw.Text("TOTAL",
                      style: labelBold, textAlign: pw.TextAlign.right)),
            ]),
            ...transaction.items.map((item) {
              return pw.TableRow(children: [
                pw.Padding(
                    padding: const pw.EdgeInsets.all(5),
                    child: pw.Text(item.description, style: bodyText)),
                pw.Padding(
                    padding: const pw.EdgeInsets.all(5),
                    child: pw.Text(item.quantity.toString(),
                        style: bodyText, textAlign: pw.TextAlign.center)),
                pw.Padding(
                    padding: const pw.EdgeInsets.all(5),
                    child: pw.Text(_formatCurrency(item.amount),
                        style: bodyText, textAlign: pw.TextAlign.center)),
                pw.Padding(
                    padding: const pw.EdgeInsets.all(5),
                    child: pw.Text(_formatCurrency(item.amount * item.quantity),
                        style: bodyText, textAlign: pw.TextAlign.right)),
              ]);
            })
          ]),
      pw.SizedBox(height: 15),

      // 5. Totals Section
      pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
        pw.Container(
            width: 150,
            decoration: pw.BoxDecoration(
                border: pw.Border(
                    top: pw.BorderSide(color: textColor),
                    bottom: pw.BorderSide(color: textColor))),
            padding: const pw.EdgeInsets.symmetric(vertical: 5),
            child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text("TOTAL", style: labelBold),
                  pw.Text(_formatCurrency(transaction.transactionTotal),
                      style: labelBold),
                ])),
        if (transaction.amountInWords != null)
          pw.Text(transaction.amountInWords!, style: microText)
      ]),

      pw.SizedBox(height: 30), // Spacer replacement

      // 6. Footer Row
      pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Expanded(
            flex: 2,
            child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text("TERMS & CONDITIONS", style: labelBold),
                  pw.Text(
                      "Goods sold in good condition are not returnable after 7 days.",
                      style: microText),
                ])),
        pw.SizedBox(width: 10),
        pw.Expanded(
            flex: 1,
            child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text("CONTACT", style: labelBold),
                  pw.Text(
                      "${profile.displayPhoneNumber ?? profile.phoneNumber}",
                      style: microText),
                  pw.SizedBox(height: 30),
                  pw.Divider(color: textColor),
                  pw.Text(profile.businessName ?? "Signatory",
                      style: labelBold),
                  pw.Text("Authorized Signatory", style: microText),
                ]))
      ])
    ]);
  }

  // --- EXISTING RECEIPT LAYOUT with Color Support ---
  pw.Widget _generateReceiptLayout(
      pw.Context context,
      BusinessProfile profile,
      Transaction transaction,
      pw.MemoryImage? logoImage,
      PdfColor primary,
      PdfColor textColor) {
    final accentColor = primary; // Use primary color for accent
    final secondaryColor = PdfColors.grey600;

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        // --- CENTERED HEADER (Flyer Style) ---
        pw.Center(
          child: pw.Column(
            children: [
              if (logoImage != null)
                pw.Container(
                  height: 60, // Smaller for A5
                  width: 60,
                  child: pw.Image(logoImage),
                )
              else
                pw.Container(
                  height: 50,
                  width: 50,
                  decoration: pw.BoxDecoration(
                    color: PdfColors.grey200,
                    shape: pw.BoxShape.circle,
                  ),
                  child: pw.Center(
                    child: pw.Text(
                      profile.businessName?.substring(0, 1).toUpperCase() ??
                          'B',
                      style: pw.TextStyle(
                        fontSize: 20,
                        fontWeight: pw.FontWeight.bold,
                        color: accentColor,
                      ),
                    ),
                  ),
                ),
              pw.SizedBox(height: 10),
              pw.Text(
                profile.businessName?.toUpperCase() ?? 'BUSINESS NAME',
                style: pw.TextStyle(
                  fontSize: 18,
                  fontWeight: pw.FontWeight.bold,
                  color: accentColor,
                ),
                textAlign: pw.TextAlign.center,
              ),
              pw.SizedBox(height: 5),
              pw.Text(
                profile.businessAddress ?? 'Business Address',
                style: const pw.TextStyle(fontSize: 10),
                textAlign: pw.TextAlign.center,
              ),
              pw.Text(
                profile.displayPhoneNumber ?? profile.phoneNumber,
                style: const pw.TextStyle(fontSize: 10),
                textAlign: pw.TextAlign.center,
              ),
              pw.SizedBox(height: 10),
              pw.Text(
                'RECEIPT',
                style: pw.TextStyle(
                    color: secondaryColor,
                    fontSize: 14,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
        ),

        pw.SizedBox(height: 20),

        // --- TRANSACTIONS  ---
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text('BILL TO:',
                style: pw.TextStyle(
                    fontSize: 10,
                    fontWeight: pw.FontWeight.bold,
                    color: secondaryColor)),
            pw.Text(transaction.customerName,
                style:
                    pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12)),
            if (transaction.customerAddress != null)
              pw.Text(transaction.customerAddress!,
                  style: const pw.TextStyle(fontSize: 10)),
            if (transaction.customerPhone != null)
              pw.Text(transaction.customerPhone!,
                  style: const pw.TextStyle(fontSize: 10)),
          ]),
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
            pw.Text('RECEIPT INFO:',
                style: pw.TextStyle(
                    fontSize: 10,
                    fontWeight: pw.FontWeight.bold,
                    color: secondaryColor)),
            pw.Text('Date: ${DateTime.now().toString().split('.')[0]}',
                style: const pw.TextStyle(fontSize: 10)),
            pw.Text(
                'No: #${transaction.date.millisecondsSinceEpoch.toString().substring(6)}',
                style: const pw.TextStyle(fontSize: 10)),
          ]),
        ]),

        pw.SizedBox(height: 10),

        // --- ITEMS TABLE ---
        pw.Table(
          columnWidths: {
            0: const pw.FlexColumnWidth(3), // Item
            1: const pw.FlexColumnWidth(1), // Qty
            2: const pw.FlexColumnWidth(1.5), // Price
            3: const pw.FlexColumnWidth(1.5), // Total
          },
          children: [
            // Header
            pw.TableRow(
              decoration: const pw.BoxDecoration(
                color: PdfColors.grey100,
                border:
                    pw.Border(bottom: pw.BorderSide(color: PdfColors.grey400)),
              ),
              children: [
                _tableHeader('DESCRIPTION'),
                _tableHeader('QTY', alignment: pw.TextAlign.center),
                _tableHeader('PRICE', alignment: pw.TextAlign.right),
                _tableHeader('TOTAL', alignment: pw.TextAlign.right),
              ],
            ),
            // Items
            ...transaction.items.map((item) {
              return pw.TableRow(
                decoration: const pw.BoxDecoration(
                  border: pw.Border(
                      bottom:
                          pw.BorderSide(color: PdfColors.grey200, width: 0.5)),
                ),
                children: [
                  _tableCell(item.description),
                  _tableCell(item.quantity.toString(),
                      alignment: pw.TextAlign.center),
                  _tableCell(_formatCurrency(item.amount),
                      alignment: pw.TextAlign.right),
                  _tableCell(_formatCurrency(item.amount * item.quantity),
                      alignment: pw.TextAlign.right),
                ],
              );
            }),
          ],
        ),

        pw.SizedBox(height: 15),

        // --- TOTALS ---
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.end,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Container(
                    padding: const pw.EdgeInsets.symmetric(
                        vertical: 5, horizontal: 10),
                    decoration: const pw.BoxDecoration(
                      color: PdfColors.grey100,
                    ),
                    child: pw.Row(children: [
                      pw.Text('TOTAL AMOUNT:   ',
                          style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                      pw.Text(
                        _formatCurrency(transaction.transactionTotal),
                        style: pw.TextStyle(
                            fontWeight: pw.FontWeight.bold, fontSize: 14),
                      ),
                    ])),
                pw.SizedBox(height: 5),
                if (transaction.amountInWords != null)
                  pw.Text(
                    '(${transaction.amountInWords})',
                    style: pw.TextStyle(
                        fontSize: 10, fontStyle: pw.FontStyle.italic),
                  ),
              ],
            ),
          ],
        ),

        pw.SizedBox(height: 30), // Spacer replacement

        // --- FOOTER ---
        pw.Divider(color: PdfColors.grey300),
        pw.SizedBox(height: 10),
        pw.SizedBox(height: 5),
        pw.Center(
          child: pw.Text(
            'Thank you for your patronage!',
            style: pw.TextStyle(
                fontSize: 12,
                fontWeight: pw.FontWeight.bold,
                fontStyle: pw.FontStyle.italic,
                color: secondaryColor),
          ),
        ),
        pw.SizedBox(height: 5),
        pw.Center(
          child: pw.Text(
            'Warranty Condition: Goods sold in good condition are not returnable after 7 days.',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey500),
          ),
        ),
        pw.SizedBox(height: 20),
      ],
    );
  }

  String _formatCurrency(double amount) {
    // Basic comma formatting
    return 'N${amount.toStringAsFixed(2).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';
  }

  pw.Widget _tableHeader(String text,
      {pw.TextAlign alignment = pw.TextAlign.left}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      child: pw.Text(
        text,
        textAlign: alignment,
        style: pw.TextStyle(
          fontWeight: pw.FontWeight.bold,
          fontSize: 10,
          color: PdfColors.grey700,
        ),
      ),
    );
  }

  pw.Widget _tableCell(String text,
      {pw.TextAlign alignment = pw.TextAlign.left}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      child: pw.Text(
        text,
        textAlign: alignment,
        style: const pw.TextStyle(fontSize: 10),
      ),
    );
  }
}

extension TransactionTotal on Transaction {
  double get transactionTotal {
    return items.fold(0, (sum, item) => sum + (item.amount * item.quantity));
  }
}
