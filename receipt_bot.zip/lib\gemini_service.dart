import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:receipt_bot/models.dart';

/// Service to interact with Google Gemini API for receipt parsing.
class GeminiService {
  /// The API key for accessing Gemini.
  final String apiKey;
  late final GenerativeModel _model;

  /// Creates a [GeminiService] with the given [apiKey].
  GeminiService({required this.apiKey}) {
    // Use gemini-1.5-flash as it is faster and widely supported
    _model = GenerativeModel(
      model: 'gemini-flash-latest',
      apiKey: apiKey,
      generationConfig: GenerationConfig(
        responseMimeType: 'application/json',
      ),
    );
  }

  /// Parses the given [text] into a [Transaction] using Gemini.
  Future<Transaction> parseTransaction(String text) async {
    final prompt = '''
    You are an expert receipt and invoice parser for Nigerian businesses.
    
    Extract the following details from the text:
    - customerName (String): The name of the buyer. If unknown, use "Customer".
    - customerAddress (String?): The buyer's address if mentioned.
    - customerPhone (String?): The buyer's phone number if mentioned.
    - items (List): List of items purchased. Each item needs:
      - description (String)
      - amount (double): Unit price or total price for the item.
      - quantity (int): Default to 1 if not specified.
    - totalAmount (double): The sum of all items. Calculate it carefully.
    - amountInWords (String): The total amount written in words (e.g. "One Thousand Two Hundred Naira Only").
    - date (String): Current date in ISO 8601 format if not specified.
    - type (String): "invoice" if the user mentions "invoice", "due date", or asks for payment later. "receipt" otherwise.
    - dueDate (String?): If it is an invoice, extract the due date in ISO 8601.
    - bankName (String?): If mentioned, the bank name for payment.
    - accountNumber (String?): If mentioned, the account number.
    - accountName (String?): If mentioned, the account name.

    Handle Nigerian currency terms:
    - "k" = 1,000 (e.g., 5k = 5000).
    - "m" = 1,000,000 (e.g., 1.2m = 1,200,000).
    - "N", "₦", "naira" are currency symbols to ignore.

    Return ONLY valid JSON matching this schema:
    {
      "customerName": "String",
      "customerAddress": "String or null",
      "customerPhone": "String or null",
      "items": [
        {"description": "String", "amount": 0.0, "quantity": 1}
      ],
      "totalAmount": 0.0,
      "amountInWords": "String",
      "date": "ISO8601_Date_String",
      "type": "receipt" or "invoice",
      "dueDate": "ISO8601_Date_String or null",
      "bankName": "String or null",
      "accountNumber": "String or null",
      "accountName": "String or null"
    }

    User Input: "$text"
    ''';

    try {
      final content = [Content.text(prompt)];
      final response = await _model.generateContent(content);

      if (response.text == null) {
        throw Exception('Gemini returned an empty response.');
      }

      // Clean up markdown code blocks if present
      final cleanJson =
          response.text!.replaceAll('```json', '').replaceAll('```', '').trim();

      final json = jsonDecode(cleanJson) as Map<String, dynamic>;

      // Auto-fill date if missing
      if (json['date'] == null || json['date'].toString().isEmpty) {
        json['date'] = DateTime.now().toIso8601String();
      }

      return Transaction.fromJson(json);
    } catch (e) {
      print('Gemini Service Error: $e');
      rethrow;
    }
  }
}
